% battery_management.m
% Manages Li-Ion Battery Charging, Discharging & SOC Tracking

clc; clear; close all;

% 🔋 Battery Parameters
battery_capacity = 104;  % Ah (Ampere-hours)
battery_voltage = 12;    % V
SOC = 50; % Initial State of Charge (%)
charging_current = 10; % A (Amps)
discharging_current = 5; % A
time = 0:1:24; % Simulating 24 hours

SOC_values = zeros(size(time));

for t = 1:length(time)
    solar_power = 200 * sin(pi * t / 24); % Simulated solar power generation
    battery_power = solar_power - 50; % Assume 50W used by load

    if SOC < 20
        SOC = SOC + (charging_current / battery_capacity) * 100;
        disp(['Hour ', num2str(t), ': Battery Low - Charging Activated']);
    elseif SOC > 90
        SOC = SOC - (discharging_current / battery_capacity) * 100;
        disp(['Hour ', num2str(t), ': Battery Full - Stop Charging']);
    else
        SOC = SOC - 2; % Normal discharge rate
    end
    
    SOC_values(t) = SOC;
end

% 📊 Plot Battery SOC Over Time
figure;
plot(time, SOC_values, 'b', 'LineWidth', 2);
xlabel('Time (hours)');
ylabel('State of Charge (%)');
title('Battery SOC Over Time');
grid on;
