% battery_sizing.m
% Calculates the required battery capacity for solar energy storage

clc; clear; close all;

% 🌞 Solar Panel Parameters
solar_power = 200;   % Watts (W) - Peak power of solar panel
sunlight_hours = 5;  % Effective sunlight hours per day

% ⚡ Energy Demand
load_power = 50;     % Watts (W) - Load consumption
load_hours = 12;     % Hours per day the load operates (adjusted for feasibility)

% 🔋 Battery Parameters
battery_voltage = 12; % Volts (V)
depth_of_discharge = 0.8; % 80% usable capacity
system_efficiency = 0.9; % Considering charge/discharge losses (90% efficient)

% 📊 Energy Calculations
daily_solar_energy = solar_power * sunlight_hours * system_efficiency;  % Wh (Watt-hours)
daily_load_energy = load_power * load_hours;  % Wh (Watt-hours)

% ⚠️ Ensure Solar Generation is Sufficient for Load
if daily_solar_energy < daily_load_energy
    warning('⚠️ Solar energy generated is LESS than energy required by the load!');
    disp('Consider increasing solar panel size or reducing load usage.');
end

% 🔍 Battery Sizing Calculation
required_battery_capacity = (daily_load_energy / battery_voltage) / depth_of_discharge; % Ah

% 🖥️ Display Results
disp('🔋 Battery Sizing Results:');
disp(['Daily Solar Energy Generated: ', num2str(daily_solar_energy), ' Wh']);
disp(['Daily Energy Consumption: ', num2str(daily_load_energy), ' Wh']);
disp(['Recommended Battery Capacity: ', num2str(round(required_battery_capacity, 2)), ' Ah']);

% 📈 Plot Energy Flow
figure;
bar([daily_solar_energy, daily_load_energy]);
set(gca, 'xticklabel', {'Solar Energy Generated', 'Energy Required by Load'});
ylabel('Energy (Wh)');
title('Daily Energy Comparison');
grid on;

% Indicate whether system is balanced
if daily_solar_energy >= daily_load_energy
    disp('✅ Solar generation is sufficient to meet the load demand.');
else
    disp('❌ Solar generation is insufficient. Consider increasing solar panel capacity.');
end
