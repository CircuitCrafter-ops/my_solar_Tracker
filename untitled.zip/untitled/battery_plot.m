% battery_plot.m
% Plots battery SOC variation over 24 hours with charging and discharging cycles

clc; clear; close all;

% 🔋 Battery Parameters
battery_capacity = 104;  % Ah (Ampere-hours)
battery_voltage = 12;    % Volts (V)
SOC_initial = 50;        % Initial SOC in %
charging_current = 10;   % A (Amps)
discharging_current = 5; % A (Amps)
depth_of_discharge = 0.8; % 80% usable capacity

% 🌞 Solar Panel Parameters
solar_power = 200;   % Watts (W)
sunlight_hours = 5;  % Effective hours of sunlight per day

% ⚡ Load Parameters
load_power = 50;     % Watts (W)
load_hours = 12;     % Load operates for 12 hours per day

% 📊 Time Simulation (24 hours)
time = 0:1:24; % 24-hour time scale
SOC = zeros(size(time)); % Array to store SOC values
SOC(1) = SOC_initial; % Set initial SOC

% 🔄 SOC Calculation Over 24 Hours
for t = 2:length(time)
    if t <= sunlight_hours  % Charging period (during the day)
        charge_Ah = (solar_power / battery_voltage) / battery_capacity * 100; % Charge contribution in %
        SOC(t) = SOC(t-1) + charge_Ah;
        SOC(t) = min(SOC(t), 100); % Ensure SOC does not exceed 100%
    else  % Discharging period (nighttime)
        discharge_Ah = (load_power * load_hours / 24) / battery_capacity * 100; % Discharge contribution in %
        SOC(t) = SOC(t-1) - discharge_Ah;
        SOC(t) = max(SOC(t), 20); % Prevent SOC from going below 20% (to avoid deep discharge)
    end
end

% 📈 Plot Battery SOC Over 24 Hours
figure;
plot(time, SOC, 'b', 'LineWidth', 2);
xlabel('Time (hours)');
ylabel('State of Charge (%)');
title('Battery SOC Over 24 Hours');
grid on;
ylim([10 110]); % Keep within practical range

% 🖥️ Display Key SOC Events
disp('🔋 Battery SOC Summary:');
disp(['Initial SOC: ', num2str(SOC_initial), '%']);
disp(['Final SOC: ', num2str(SOC(end)), '%']);
disp(['Max SOC: ', num2str(max(SOC)), '%']);
disp(['Min SOC: ', num2str(min(SOC)), '%']);

if min(SOC) <= 20
    disp('⚠️ Warning: Battery SOC is critically low. Consider increasing storage capacity.');
end
if max(SOC) >= 100
    disp('⚠️ Warning: Battery is fully charged. Consider adding a charge controller.');
end
