% Battery Parameters
battery_capacity = 104;  % Ah
battery_voltage = 12;    % V
SOC = 50; % Initial SOC in percentage
charging_current = 10; % Amps
discharging_current = 5; % Amps

% Time simulation for 24 hours
time = 0:1:24;
SOC_values = zeros(size(time));

for t = 1:length(time)
    solar_power = 200 * sin(pi * t / 24); % Simulated solar power
    battery_power = solar_power - 50; % Assume 50W is used for load
    
    if SOC < 20
        SOC = SOC + (charging_current / battery_capacity) * 100;
        disp('Battery Low: Charging Activated');
    elseif SOC > 90
        SOC = SOC - (discharging_current / battery_capacity) * 100;
        disp('Battery Full: Stop Charging');
    else
        SOC = SOC - 2; % Normal discharge
    end
    
    SOC_values(t) = SOC;
end

% Plot Battery SOC over time
plot(time, SOC_values, 'b', 'LineWidth', 2);
xlabel('Time (hours)');
ylabel('State of Charge (%)');
title('Battery SOC Over Time');
grid on;
